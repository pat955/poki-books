# import unittest
# from frames import NoteBook

# class NoteBookTest(unittest.TestCase):
#     def cache_path(self):
#         nb = NoteBook()
#         self.assertEqual
