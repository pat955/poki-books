"""
-- main.py --
Initializes window that starts the bookbot program
"""
from window import BookBot

def main():
    BookBot()

main()
